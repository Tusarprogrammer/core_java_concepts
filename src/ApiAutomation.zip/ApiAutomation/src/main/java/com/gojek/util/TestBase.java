package com.gojek.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
/**
 * TestBase class which will be common for reading configs
 * @author tpati
 *
 */
public class TestBase {
	
public static Properties properties;
	
	public static void init(){
		properties = new Properties();
		try {
			FileInputStream fip = new FileInputStream("C:\\eclipse_workspace\\api_automation_assignment\\ApiAutomation\\src\\main\\java\\com\\gojek\\config\\config.properties");
			properties.load(fip);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
	}
	

}
