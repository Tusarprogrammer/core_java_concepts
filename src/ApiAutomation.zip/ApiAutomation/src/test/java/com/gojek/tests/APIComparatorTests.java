package com.gojek.tests;

import org.apache.commons.lang3.StringUtils;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.gojek.util.TestBase;
import com.gojek.util.TestUtil;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;


public class APIComparatorTests extends TestBase{

	boolean check = true;
	@BeforeMethod
	public void setUp(){
		TestBase.init();
	}

	@DataProvider
	public Object[][] getData(){
		Object testData[][] = TestUtil.getDataFromSheet(TestUtil.URL_LIST_SHEET_NAME);
		return testData;
	}

	/*
	@Test(dataProvider="getData")
	public void checkUrlsDifferent(String fisrtUrl,String secondUrl){
		Assert.assertEquals(compareUrlStrings(fisrtUrl, secondUrl), false);
	}	
	*/
	
	@Test(dataProvider="getData")
	public void checkUrlsResponse(String fisrtUrl,String secondUrl){
		        //define the http request:
				RequestSpecification httpRequest = RestAssured.given();

				Response firstAPIResponse = httpRequest.request(Method.GET, fisrtUrl);
				Response secondAPIResponse = httpRequest.request(Method.GET, secondUrl);
				
				//get the response body:
				String firstAPIResponseBody = firstAPIResponse.getBody().asString();
				String secondAPIResponseBody = secondAPIResponse.getBody().asString();
				
				//get the status code
				int firstAPIStatusCode = firstAPIResponse.getStatusCode();
				int secondAPIStatusCode = secondAPIResponse.getStatusCode();
				
				//get the headers info
				String firstAPIHeaderContentType = firstAPIResponse.getHeader("Content-Type");
				String firstAPIHeaderContentLength = firstAPIResponse.getHeader("Content-Length");
				String secondAPIHeaderContentType = secondAPIResponse.getHeader("Content-Type");
     			String secondAPIHeaderContentLength = secondAPIResponse.getHeader("Content-Length");
	if(firstAPIResponseBody.equals(secondAPIResponseBody) && firstAPIStatusCode == secondAPIStatusCode && firstAPIHeaderContentType.equals(secondAPIHeaderContentType) && StringUtils.equals(firstAPIHeaderContentLength, secondAPIHeaderContentLength)) {
		System.out.println(fisrtUrl + " equals " + secondUrl);
	} else {
		System.out.println(fisrtUrl + " not equals " + secondUrl);
	}
				
				
	}	
	
	/*
	private boolean compareUrlStrings(String fisrtUrl,String secondUrl) {
		if(fisrtUrl.equals(secondUrl)) {
		return true;
		} else {
			return false;
		}
	}
	*/
	
}


