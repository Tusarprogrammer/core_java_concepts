package com.gojek.tests;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.gojek.pojo.User;
import com.gojek.util.TestBase;
import com.gojek.util.TestUtil;
import com.google.gson.Gson;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

/**
 * API comparator test cases
 * @author tpati
 *
 */
public class APIComparatorTests extends TestBase{

	boolean check = true;
	@BeforeMethod
	public void setUp(){
		TestBase.init();
	}

	@DataProvider
	public Object[][] getData(){
		Object testData[][] = TestUtil.getDataFromSheet(TestUtil.URL_LIST_SHEET_NAME);
		return testData;
	}

	/*
	@Test(dataProvider="getData")
	public void checkUrlsDifferent(String fisrtUrl,String secondUrl){
		Assert.assertEquals(compareUrlStrings(fisrtUrl, secondUrl), false);
	}	
	*/
	
	@Test(dataProvider="getData")
	public void checkUrlsResponse(String fisrtUrl,String secondUrl){
		        
				SoftAssert softAssert = new SoftAssert();
				//define the http request:
				RequestSpecification httpRequest = RestAssured.given();

				Response firstAPIResponse = httpRequest.request(Method.GET, fisrtUrl);
				Response secondAPIResponse = httpRequest.request(Method.GET, secondUrl);
				
				//get the response body:
				String firstAPIResponseBody = firstAPIResponse.getBody().asString();
				String secondAPIResponseBody = secondAPIResponse.getBody().asString();
				
				// converting json to java objects
				Gson gson = new Gson();
				User getUserDetailResponseForFirstAPI = gson.fromJson(firstAPIResponseBody, User.class);
				User getUserDetailResponseForSecondAPI = gson.fromJson(secondAPIResponseBody, User.class);

				//get the status code
				int firstAPIStatusCode = firstAPIResponse.getStatusCode();
				int secondAPIStatusCode = secondAPIResponse.getStatusCode();
				
				//status code 200 stand for OK
     			if((firstAPIStatusCode == TestUtil.RESPONSE_CODE_200 && secondAPIStatusCode == TestUtil.RESPONSE_CODE_200) && getUserDetailResponseForFirstAPI.equals(getUserDetailResponseForSecondAPI)) {
     				softAssert.assertTrue(true,fisrtUrl + " equals " + secondUrl);
     			} else {
     				softAssert.assertTrue(false,fisrtUrl + " not equals " + secondUrl);
     			}
				
     			softAssert.assertAll();
	}	
	
	/*
	private boolean compareUrlStrings(String fisrtUrl,String secondUrl) {
		if(fisrtUrl.equals(secondUrl)) {
		return true;
		} else {
			return false;
		}
	}
	*/
	
}


