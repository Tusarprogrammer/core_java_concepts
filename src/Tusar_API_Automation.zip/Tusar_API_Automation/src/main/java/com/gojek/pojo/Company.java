package com.gojek.pojo;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * POJO class for Company
 * @author tpati
 *
 */
		
public class Company implements Serializable{

/**
	 * 
	 */
	private static final long serialVersionUID = -6617670848885446928L;
@SerializedName("name")
@Expose
private String name;
@SerializedName("catchPhrase")
@Expose
private String catchPhrase;
@SerializedName("bs")
@Expose
private String bs;

public String getName() {
return name;
}

public void setName(String name) {
this.name = name;
}

public String getCatchPhrase() {
return catchPhrase;
}

@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((bs == null) ? 0 : bs.hashCode());
	result = prime * result + ((catchPhrase == null) ? 0 : catchPhrase.hashCode());
	result = prime * result + ((name == null) ? 0 : name.hashCode());
	return result;
}

@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Company other = (Company) obj;
	if (bs == null) {
		if (other.bs != null)
			return false;
	} else if (!bs.equals(other.bs))
		return false;
	if (catchPhrase == null) {
		if (other.catchPhrase != null)
			return false;
	} else if (!catchPhrase.equals(other.catchPhrase))
		return false;
	if (name == null) {
		if (other.name != null)
			return false;
	} else if (!name.equals(other.name))
		return false;
	return true;
}

public void setCatchPhrase(String catchPhrase) {
this.catchPhrase = catchPhrase;
}

public String getBs() {
return bs;
}

public void setBs(String bs) {
this.bs = bs;
}

}
